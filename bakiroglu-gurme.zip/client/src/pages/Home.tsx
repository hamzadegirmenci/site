/*
 * Bakıroğlu GURME — Ana Sayfa
 * Tasarım: "Bostancı Sabahı" — Modern Akdeniz Minimalizmi
 * Renk: Kırık beyaz, antrasit, zeytin yeşili, sıcak amber
 * Tipografi: Cormorant Garamond (başlıklar) + Source Sans 3 (gövde)
 * Layout: Sticky header, hero tam ekran, tek sayfa scroll
 */

import { useEffect, useRef, useState } from "react";
import {
  Phone,
  MapPin,
  Clock,
  Star,
  ChevronDown,
  Menu,
  X,
  Navigation,
  ShoppingBag,
  Leaf,
  Heart,
  Award,
} from "lucide-react";

// Üretilen görsel URL'leri
const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663479462370/YLVQnbXyfVYRMMg2nyqoUJ/hero-kahvalti-hP4ucFC32myo7iSg8KGcG8.webp";
const MENEMEN_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663479462370/YLVQnbXyfVYRMMg2nyqoUJ/menemen-close-dtxkZQ5rGf38YxEBkoutdi.webp";
const PISI_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663479462370/YLVQnbXyfVYRMMg2nyqoUJ/pisi-fresh-WeTYHbNyWCZKLzwkN2NHm9.webp";
const SARKUTERI_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663479462370/YLVQnbXyfVYRMMg2nyqoUJ/sarkuteri-tabagi-VUKLZxhfBiffquHPvPdCVQ.webp";
const SUCUK_HELLIM_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663479462370/YLVQnbXyfVYRMMg2nyqoUJ/sucuk-hellim-Y7Su9nqd4UUK89KTFe4RVh.webp";

// Scroll reveal hook
function useReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.12 }
    );
    const elements = document.querySelectorAll(".reveal");
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useReveal();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* ── STICKY HEADER ── */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-border"
            : "bg-transparent"
        }`}
      >
        <div className="container flex items-center justify-between h-16 md:h-18">
          {/* Logo */}
          <button
            onClick={() => scrollTo("hero")}
            className="flex flex-col leading-none"
          >
            <span
              className={`font-display text-xl md:text-2xl font-bold tracking-tight transition-colors ${
                scrolled ? "text-foreground" : "text-white"
              }`}
            >
              Bakıroğlu
            </span>
            <span
              className={`font-body text-xs font-semibold tracking-[0.2em] uppercase transition-colors ${
                scrolled ? "text-primary" : "text-amber-200"
              }`}
            >
              GURME
            </span>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {[
              { label: "Neden Biz?", id: "neden-biz" },
              { label: "Lezzetler", id: "lezzetler" },
              { label: "Yorumlar", id: "yorumlar" },
              { label: "İletişim", id: "iletisim" },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className={`font-body text-sm font-medium transition-colors hover:text-primary ${
                  scrolled ? "text-foreground" : "text-white/90"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* CTA Butonları — her zaman görünür */}
          <div className="flex items-center gap-2">
            <a
              href="https://maps.google.com/?q=Bakıroğlu+Gurme+Bostancı+İstanbul"
              target="_blank"
              rel="noopener noreferrer"
              className={`flex items-center gap-1.5 border px-3 py-2 rounded-full text-xs font-semibold font-body transition-colors ${
                scrolled
                  ? "border-border text-foreground hover:bg-secondary"
                  : "bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20"
              }`}
            >
              <Navigation size={13} />
              <span className="hidden sm:inline">Yol Tarifi</span>
            </a>
            {/* Mobil menü */}
            <button
              className={`md:hidden p-2 transition-colors ${scrolled ? "text-foreground" : "text-white"}`}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Menü"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

          {/* Mobil Açılır Menü */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-border shadow-lg">
            <nav className="container py-4 flex flex-col gap-1">
              {[
                { label: "Neden Biz?", id: "neden-biz" },
                { label: "Lezzetler", id: "lezzetler" },
                { label: "Yorumlar", id: "yorumlar" },
                { label: "İletişim", id: "iletisim" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollTo(item.id)}
                  className="text-left font-body text-base font-medium text-foreground py-3 border-b border-border/50 last:border-0 hover:text-primary transition-colors"
                >
                  {item.label}
                </button>
              ))}
              <div className="pt-3">
                <a
                  href="https://maps.google.com/?q=Bakıroğlu+Gurme+Bostancı+İstanbul"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 border border-primary text-primary py-3 rounded-lg text-sm font-semibold font-body w-full"
                >
                  <Navigation size={15} /> Yol Tarifi
                </a>
              </div>
            </nav>
          </div>
        )}
      </header>

      {/* ── HERO BÖLÜMÜ ── */}
      <section
        id="hero"
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
      >
        {/* Arka plan görseli */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="Bakıroğlu GURME kahvaltı sofrası"
            className="w-full h-full object-cover"
          />
          {/* Karanlık overlay — metin okunabilirliği için */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/65 via-black/45 to-black/70" />
        </div>

        {/* Hero içerik */}
        <div className="relative z-10 container text-center text-white px-4">
          {/* Üst etiket */}
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-1.5 mb-6">
            <MapPin size={13} className="text-amber-300" />
            <span className="font-body text-xs font-medium tracking-widest uppercase text-white/90">
              Bostancı, Kadıköy
            </span>
          </div>

          {/* Ana başlık */}
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-tight mb-4">
            Bakıroğlu
            <br />
            <span className="italic font-semibold text-amber-200">GURME</span>
          </h1>

          {/* Slogan */}
          <p className="font-display text-xl md:text-2xl italic text-white/90 mb-3">
            Gerçek Lezzet, Sıfır İsraf.
          </p>

          {/* Alt başlık */}
          <p className="font-body text-base md:text-lg text-white/75 max-w-2xl mx-auto mb-10 leading-relaxed">
            Zoraki serpme kahvaltılara son! Sadece istediğiniz ürünleri seçin,
            masanızda israfa yer bırakmayın.{" "}
            <span className="text-amber-200 font-medium">
              Bostancı'nın en taze şarküteri ürünleriyle
            </span>{" "}
            kendi kahvaltınızı tasarlayın.
          </p>

          {/* CTA Butonları */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => scrollTo("lezzetler")}
              className="w-full sm:w-auto flex items-center justify-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-base font-semibold font-body hover:bg-primary/90 transition-all hover:scale-105 shadow-lg shadow-primary/30"
            >
              <ShoppingBag size={18} />
              Menüyü Gör
            </button>
            <a
              href="https://maps.google.com/?q=Prof.+Dr.+Ali+Nihat+Tarlan+Cd+47-9+Bostancı+Kadıköy+İstanbul"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm border border-white/30 text-white px-8 py-4 rounded-full text-base font-semibold font-body hover:bg-white/20 transition-all hover:scale-105"
            >
              <Navigation size={18} />
              Yol Tarifi Al
            </a>
          </div>

          {/* Google puanı */}
          <div className="flex items-center justify-center gap-2 mt-10">
            <div className="flex">
              {[1, 2, 3, 4].map((i) => (
                <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
              ))}
              <Star size={16} className="fill-amber-400/50 text-amber-400" />
            </div>
            <span className="font-body text-sm text-white/80">
              <strong className="text-white">4.5</strong> · Google'da 1.100+ yorum
            </span>
          </div>
        </div>

        {/* Aşağı kaydır oku */}
        <button
          onClick={() => scrollTo("neden-biz")}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/60 hover:text-white transition-colors animate-bounce"
          aria-label="Aşağı kaydır"
        >
          <ChevronDown size={28} />
        </button>
      </section>

      {/* ── NEDEN BİZ? ── */}
      <section id="neden-biz" className="py-24 md:py-32 bg-background">
        <div className="container">
          {/* Bölüm başlığı */}
          <div className="text-center mb-16 reveal">
            <span className="font-body text-xs font-semibold tracking-[0.25em] uppercase text-primary mb-3 block">
              Farkımız
            </span>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground">
              Neden <span className="italic text-primary">Bakıroğlu?</span>
            </h2>
            <div className="w-16 h-0.5 bg-primary mx-auto mt-4" />
          </div>

          {/* Özellik kartları */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <ShoppingBag size={28} />,
                title: "Kendi Tabağını Oluştur",
                desc: "Dayatma yok. Şarküterimizden dilediğin peyniri, zeytini ve sıcakları seç, sadece yediğini öde. Serpme kahvaltı kültürünü yeniden tanımlıyoruz.",
                delay: "0ms",
              },
              {
                icon: <Heart size={28} />,
                title: "Anne Eli Değmiş Gibi",
                desc: "Menemen, pişi ve karışık omlet gibi sıcaklarımız ev yapımı doğallığında ve taptaze. Her sabah hazırlanan, katkısız lezzetler.",
                delay: "120ms",
              },
              {
                icon: <Award size={28} />,
                title: "Şarküteri Kalitesi",
                desc: "Sofrada beğendiğiniz her ürünü şarküteri reyonumuzdan evinize paket yaptırabilirsiniz. Türkiye'nin dört bir yanından seçme peynir ve zeytinler.",
                delay: "240ms",
              },
            ].map((item, i) => (
              <div
                key={i}
                className="reveal group p-8 rounded-2xl border border-border bg-card hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 hover:-translate-y-1"
                style={{ transitionDelay: item.delay }}
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                  {item.icon}
                </div>
                <h3 className="font-display text-2xl font-semibold text-foreground mb-3">
                  {item.title}
                </h3>
                <p className="font-body text-muted-foreground leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>

          {/* İkincil özellik satırı */}
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 reveal">
            {[
              { icon: <Leaf size={18} />, label: "Taze & Doğal" },
              { icon: <Clock size={18} />, label: "Her Gün 08:00–21:00" },
              { icon: <MapPin size={18} />, label: "Bostancı Kalbinde" },
              { icon: <Star size={18} />, label: "1.100+ Google Yorumu" },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center gap-3 p-4 rounded-xl bg-secondary/60"
              >
                <span className="text-primary">{item.icon}</span>
                <span className="font-body text-sm font-medium text-foreground">
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── POPÜLER LEZZETLER ── */}
      <section id="lezzetler" className="py-24 md:py-32 bg-secondary/30">
        <div className="container">
          {/* Bölüm başlığı */}
          <div className="text-center mb-16 reveal">
            <span className="font-body text-xs font-semibold tracking-[0.25em] uppercase text-primary mb-3 block">
              Menü
            </span>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground">
              Popüler <span className="italic text-primary">Lezzetler</span>
            </h2>
            <div className="w-16 h-0.5 bg-primary mx-auto mt-4" />
            <p className="font-body text-muted-foreground mt-4 max-w-lg mx-auto">
              Her sabah taze hazırlanan, özel tariflerimizle hayat bulan
              lezzetler.
            </p>
          </div>

          {/* Galeri grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            {/* Pişi */}
            <div className="reveal group overflow-hidden rounded-2xl shadow-md hover:shadow-xl transition-all duration-300">
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={PISI_IMG}
                  alt="Pişi ve hamur işleri"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <span className="font-body text-xs font-semibold tracking-widest uppercase text-amber-300 block mb-1">
                    Hamur İşleri
                  </span>
                  <h3 className="font-display text-2xl font-bold">
                    Pişi & Hamur İşleri
                  </h3>
                  <p className="font-body text-sm text-white/80 mt-1">
                    Çıtır çıtır, yağ çekmeyen özel tarif.
                  </p>
                </div>
              </div>
            </div>

            {/* Menemen */}
            <div className="reveal group overflow-hidden rounded-2xl shadow-md hover:shadow-xl transition-all duration-300">
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={MENEMEN_IMG}
                  alt="Bakıroğlu Menemen"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <span className="font-body text-xs font-semibold tracking-widest uppercase text-amber-300 block mb-1">
                    Sıcaklar
                  </span>
                  <h3 className="font-display text-2xl font-bold">
                    Bakıroğlu Menemen
                  </h3>
                  <p className="font-body text-sm text-white/80 mt-1">
                    Tam kıvamında, taze sebzelerle.
                  </p>
                </div>
              </div>
            </div>

            {/* Sucuk Hellim */}
            <div className="reveal group overflow-hidden rounded-2xl shadow-md hover:shadow-xl transition-all duration-300">
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={SUCUK_HELLIM_IMG}
                  alt="Sucuk Hellim"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <span className="font-body text-xs font-semibold tracking-widest uppercase text-amber-300 block mb-1">
                    Sıcaklar
                  </span>
                  <h3 className="font-display text-2xl font-bold">
                    Sucuk Hellim
                  </h3>
                  <p className="font-body text-sm text-white/80 mt-1">
                    Izgara hallumi ve sucuk, taze ve lezzetli.
                  </p>
                </div>
              </div>
            </div>

            {/* Şarküteri Tabağı */}
            <div className="reveal group overflow-hidden rounded-2xl shadow-md hover:shadow-xl transition-all duration-300">
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={SARKUTERI_IMG}
                  alt="Özel Şarküteri Tabağı"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <span className="font-body text-xs font-semibold tracking-widest uppercase text-amber-300 block mb-1">
                    Şarküteri
                  </span>
                  <h3 className="font-display text-2xl font-bold">
                    Özel Şarküteri Tabağı
                  </h3>
                  <p className="font-body text-sm text-white/80 mt-1">
                    Türkiye'nin dört bir yanından seçme peynir ve zeytinler.
                  </p>
                </div>
              </div>
            </div>
          </div>


        </div>
      </section>

      {/* ── MÜŞTERİ DENEYİMİ ── */}
      <section id="yorumlar" className="py-24 md:py-32 bg-background">
        <div className="container">
          <div className="text-center mb-16 reveal">
            <span className="font-body text-xs font-semibold tracking-[0.25em] uppercase text-primary mb-3 block">
              Müşteri Deneyimi
            </span>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground">
              Onlar <span className="italic text-primary">Anlattı</span>
            </h2>
            <div className="w-16 h-0.5 bg-primary mx-auto mt-4" />
          </div>

          {/* Google puanı büyük gösterim */}
          <div className="reveal max-w-3xl mx-auto">
            <div className="bg-card border border-border rounded-2xl p-8 md:p-12 shadow-sm">
              <div className="flex flex-col md:flex-row items-center gap-8">
                {/* Puan */}
                <div className="text-center shrink-0">
                  <div className="font-display text-7xl font-bold text-foreground leading-none">
                    4.5
                  </div>
                  <div className="flex justify-center gap-1 mt-2">
                    {[1, 2, 3, 4].map((i) => (
                      <Star key={i} size={20} className="fill-amber-400 text-amber-400" />
                    ))}
                    <Star size={20} className="fill-amber-400/50 text-amber-400" />
                  </div>
                  <div className="font-body text-sm text-muted-foreground mt-2">
                    1.100+ Google Yorumu
                  </div>
                </div>

                {/* Dikey ayırıcı */}
                <div className="hidden md:block w-px h-24 bg-border" />

                {/* Yorum */}
                <div>
                  <blockquote className="font-display text-xl md:text-2xl italic text-foreground leading-relaxed mb-4">
                    "Bostancı'da kahvaltı denince aklıma gelen tek yer. Tabakta
                    ziyan yok, damak zevki var. Servis hızlı, çalışanlar güler
                    yüzlü."
                  </blockquote>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center">
                      <span className="font-display text-base font-bold text-primary">
                        E
                      </span>
                    </div>
                    <div>
                      <div className="font-body font-semibold text-foreground text-sm">
                        Emre Y.
                      </div>
                      <div className="font-body text-xs text-muted-foreground">
                        Yerel Rehber · Google Maps
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* İkincil yorumlar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
              {[
                {
                  text: "Pişileri muhteşem, her sabah taze. Şarküteri bölümü de çok kaliteli.",
                  name: "Ayşe K.",
                  role: "Düzenli Müşteri",
                },
                {
                  text: "Sadece istediğimi seçip ödüyorum, israf yok. Bostancı'nın en iyi kahvaltısı.",
                  name: "Murat D.",
                  role: "Google Yorumu",
                },
              ].map((yorum, i) => (
                <div
                  key={i}
                  className="reveal bg-secondary/50 rounded-xl p-6 border border-border/50"
                >
                  <div className="flex mb-3">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} size={13} className="fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <p className="font-body text-sm text-foreground/80 italic mb-4">
                    "{yorum.text}"
                  </p>
                  <div className="font-body text-xs font-semibold text-foreground">
                    {yorum.name}{" "}
                    <span className="font-normal text-muted-foreground">
                      · {yorum.role}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── İLETİŞİM & KONUM ── */}
      <section id="iletisim" className="py-24 md:py-32 bg-foreground text-background">
        <div className="container">
          <div className="text-center mb-16 reveal">
            <span className="font-body text-xs font-semibold tracking-[0.25em] uppercase text-amber-400 mb-3 block">
              Bizi Bulun
            </span>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-background">
              İletişim &{" "}
              <span className="italic text-amber-300">Konum</span>
            </h2>
            <div className="w-16 h-0.5 bg-amber-400 mx-auto mt-4" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start max-w-5xl mx-auto">
            {/* Bilgi kartları */}
            <div className="space-y-6 reveal">
              {[
                {
                  icon: <MapPin size={22} />,
                  title: "Adres",
                  content: "Prof. Dr. Ali Nihat Tarlan Cd 47-9",
                  sub: "Bostancı, Kadıköy / İstanbul",
                  link: "https://maps.google.com/?q=Prof.+Dr.+Ali+Nihat+Tarlan+Cd+47-9+Bostancı+Kadıköy+İstanbul",
                  linkLabel: "Haritada Gör",
                },
                {
                  icon: <Clock size={22} />,
                  title: "Çalışma Saatleri",
                  content: "Her gün 08:00 – 21:00",
                  sub: "Salı açılış: 08:30",
                  link: null,
                  linkLabel: null,
                },
                {
                  icon: <Phone size={22} />,
                  title: "Telefon",
                  content: "(0216) 362 30 25",
                  sub: "Rezervasyon & Paket Sipariş",
                  link: "tel:02163623025",
                  linkLabel: "Hemen Ara",
                },
              ].map((item, i) => (
                <div
                  key={i}
                  className="flex items-start gap-5 p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/8 transition-colors"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center text-primary shrink-0">
                    {item.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-body text-xs font-semibold tracking-widest uppercase text-background/50 mb-1">
                      {item.title}
                    </div>
                    <div className="font-display text-xl font-semibold text-background">
                      {item.content}
                    </div>
                    <div className="font-body text-sm text-background/60 mt-0.5">
                      {item.sub}
                    </div>
                    {item.link && (
                      <a
                        href={item.link}
                        target={item.link.startsWith("http") ? "_blank" : undefined}
                        rel={item.link.startsWith("http") ? "noopener noreferrer" : undefined}
                        className="inline-flex items-center gap-1 font-body text-sm font-semibold text-primary mt-2 hover:text-amber-300 transition-colors"
                      >
                        {item.linkLabel} →
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Harita */}
            <div className="reveal rounded-2xl overflow-hidden border border-white/10 shadow-2xl aspect-[4/3]">
              <iframe
                title="Bakıroğlu GURME Konum"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3012.6!2d29.0968!3d40.9627!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cac6b8e7d4f1e3%3A0x5e8f2a6b3c1d7e9a!2sProf.+Dr.+Ali+Nihat+Tarlan+Cd+47-9%2C+Bost%C3%A2nc%C4%B1%2C+Kad%C4%B1k%C3%B6y%2F%C4%B0stanbul!5e0!3m2!1str!2str!4v1700000000000!5m2!1str!2str"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="bg-black py-8 border-t border-white/5">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-col items-center md:items-start">
            <span className="font-display text-lg font-bold text-white">
              Bakıroğlu <span className="text-primary">GURME</span>
            </span>
            <span className="font-body text-xs text-white/40 mt-1">
              Bostancı'da Kahvaltının ve Şarküterinin Tek Adresi
            </span>
          </div>
          <div className="flex items-center gap-4">
            <a
              href="tel:02163623025"
              className="font-body text-sm text-white/60 hover:text-white transition-colors flex items-center gap-1.5"
            >
              <Phone size={13} /> (0216) 362 30 25
            </a>
            <span className="text-white/20">·</span>
            <span className="font-body text-sm text-white/40">
              © {new Date().getFullYear()} Bakıroğlu GURME
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
